<?php
/**
 * Add the edit link for posts and pages
 *
 * @package Opti
 */

edit_post_link( __( 'Edit', 'opti' ), '', '' ); ?>